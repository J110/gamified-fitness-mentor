# 10 — Folder Structure

repo/
  frontend/ (React+Vite recommended; or vanilla)
  backend/ (Node/Express)
  shared/ (JSON libraries)
