# 07 — Frontend UI Spec

Single page sections:
1) Header + Reset
2) User seed inputs
3) Assessment panel (blank -> generated) + interpretations
4) Chapter dashboard (4 tiles visible; current highlighted; clickable)
5) Mentor panel (video + transcript + replay)
6) Skill cards panel (3 cards; none/partial/full)
7) Progress panel (momentum, trust, identity, unlocks)

Loading states:
- disable generate until JSON libs loaded
- show spinner while D-ID video generating
