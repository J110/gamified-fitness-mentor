# Implementation Checklist

1) Frontend skeleton + UI
2) Load JSON libs
3) Seeded tracking generator + derivations
4) Chapter scoring + stage + dashboard
5) Skill card scoring + selection + completion
6) Mentor narrative selection + interpolation
7) D-ID backend proxy + caching + polling
8) Frontend D-ID client + fallback
9) Acceptance tests + test-case loader
