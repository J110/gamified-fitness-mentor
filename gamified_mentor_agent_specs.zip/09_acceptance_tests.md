# 09 — Acceptance Tests

Must pass:
- blank assessments first
- generate shows values + interpretations
- stages correct per thresholds
- card selection targets weak metrics + respects cooldown
- completion updates momentum/trust/history
- mentor variant switches (none => recovery)
- D-ID calls backend; polling yields video; fallback works
- reset clears all
